1. install qemu with risc-v support
You can follow xv6 2020 util instructions: https://pdos.csail.mit.edu/6.828/2020/tools.html

2.run run.sh

3.run `sctf` command in xv6 console.

4.Have fun!
